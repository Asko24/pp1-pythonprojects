'''
Obliczanie pola powierzchni i obwodu koła o zadanym promieniu
'''

import math
r=5
obwod=2*math.pi*r
pole=math.pi*r**2
print(f'Pole koła wynosi: {pole}\nObwód koła wynosi: {obwod}')