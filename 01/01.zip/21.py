c=input('Podaj ilosc stopni Celsjusza: ')
k=float(c)+273.15
print('Podana temperatura w stopniach Kelwina: ',k)