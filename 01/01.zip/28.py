import random
x=int(random.randint(1,6))
y=int(random.randint(1,6))
z=int(random.randint(1,6))

print(f'Rzut 1: {x}\nRzut 2: {y}\nRzut 3: {z}')
print('Suma oczek: ',x+y+z)
