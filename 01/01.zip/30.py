tab=[12,6,4,9,3]

print(tab[0],':',tab[0]*'*')
print(tab[1],':',tab[1]*'*')
print(tab[2],':',tab[2]*'*')
print(tab[3],':',tab[3]*'*')
print(tab[4],':',tab[4]*'*')

'''
for i in tab:
    print (i,':',i*'*')
'''