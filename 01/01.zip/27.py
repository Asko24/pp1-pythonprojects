x=int(input('Podaj pierwsza liczbe: '))
y=int(input('Podaj druga liczbe: '))

import math
print(f'Najwiekszy wspolny dzielnik liczb {x} i {y}: {math.gcd(x,y)}')
