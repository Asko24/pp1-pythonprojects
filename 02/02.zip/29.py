tab=[15,8,31,47,2,19]
print('tab: ',end='')
for i in tab:
    print (i,end=' ')
print('\ntab in reverse: ',end='')
for j in reversed(tab):
    print(j,end=' ')