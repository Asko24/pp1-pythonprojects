x=int(input('Wprowadz dowolną liczbę całkowitą: '))

if x>0 and x%2==1:
    print('Liczba jest dodatnia i nieparzysta')
else:
    print('Liczba jest ujemna lub parzysta')