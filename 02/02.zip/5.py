import random
wiek=random.randint(0,100)
print('Wiek: ',wiek)
if wiek>=18:
    print('Osoba pełnoletnia')
else:
    print('Osoba niepełnoletnia')