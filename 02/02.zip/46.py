import random


i=0
while i<20:
    i+=1
    print(int(random.randrange(-20,-5)))