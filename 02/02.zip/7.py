i=0
while i<5:
    print('Piotr')
    i+=1