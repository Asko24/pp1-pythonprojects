for i in range (1,11):
    print(f'1/{i} = {1/i}')