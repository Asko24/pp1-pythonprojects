import random
x=random.randint(-100,100)
print(x)
if x%2==0:
    print('Liczba parzysta')
else:
    print('Liczba nieparzysta')