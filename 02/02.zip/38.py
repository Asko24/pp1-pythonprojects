i=7
while i<10:
    print(i, end=' ')
    i += 1
print()

j=4
while j<7:
    print(j, end=' ')
    j+=1
print()

k=1
while k<4:
    print(k, end =' ')
    k+=1