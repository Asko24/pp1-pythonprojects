import random
wiek=random.randint(-100000,100000)
print (wiek)
if wiek>10:
    print('Liczba większa od 10')
else:
    print('Liczba mniejsza od 10')