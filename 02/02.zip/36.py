x=2
while 1<2:
    if x%7==0 and x%2==1 and x%3==1 and x%4==1 and x%5==1 and x%6==1:
        break
    else:
        x+=1
print(x)