x=int(input('Wprowadz pierwszą liczbe całkowitą: '))
y=int(input('Wprowadz drugą liczbę całkowitą: '))

if x<0 or y<0:
    print('Jedna z liczb posiada wartośc ujemną')
else:
    print('Obie liczby są dodatnie')