x=1
for i in range(1,50):
    print(f'{x}', end=' ')
    x+=7
    if x>43:
        break
print()
x=2
for i in range(1,50):
    print(f'{x}', end=' ')
    x+=7
    if x>44:
        break
print()
x=3
for i in range(1,50):
    print(f'{x}', end=' ')
    x+=7
    if x>45:
        break
print()
x=4
for i in range(1,50):
    print(f'{x}', end=' ')
    x+=7
    if x>46:
        break
print()
x=5
for i in range(1,50):
    print(f'{x}', end=' ')
    x+=7
    if x>47:
        break
print()
x=6
for i in range(1,50):
    print(f'{x}', end=' ')
    x+=7
    if x>48:
        break
print()
x=7
for i in range(1,50):
    print(f'{x}', end=' ')
    x+=7
    if x>49:
        break
print() 