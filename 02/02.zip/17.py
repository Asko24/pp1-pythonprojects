suma_p=0
for i in range (1,51,2):
    i+=1
    suma_p+=i
    

print('Suma liczb parzystych z przedziału <1,50>: ',suma_p)

suma_n=0
for i in range (1,51,2):
    suma_n+=i
print('Suma liczb nieparzystych z przedziału <1,50>: ',suma_n)