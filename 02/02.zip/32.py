x=input('Wprowadz dowolny ciąg znaków: ')
for i in reversed(x):
    print(i,end='')