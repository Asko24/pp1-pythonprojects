for i in range (1,24):
    if i&7!=0:
        print('*',end='')
    else:
        print('\n',end='')