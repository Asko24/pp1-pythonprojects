uczelnia='UEK w Krakowie'
print('Uczelnia: ',uczelnia)

print('Szeroko: ',end='')
for i in range (0,len(uczelnia)):
    print(uczelnia[i],end=' ')