with open ('NoEducation.txt','r') as file:
    print (file.read())