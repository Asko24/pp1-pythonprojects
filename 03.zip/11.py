with open ('DanePersonalne.txt','w') as file:
    file.write('Piotr Gałecki\nUniwersytet Ekonomiczny w Krakowie\nInformatyka Stosowana')