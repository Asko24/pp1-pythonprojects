import time

start_time=time.time()

suma=0

for i in range (0,100000001):
    suma+=1
print(i)
'''
while suma<100000000:
    suma+=1
print(suma)
'''
print(f'--- {time.time()-start_time} ---')