import random

tab=[]
def rzucKostka(ilosc):
    for i in range (0,ilosc):
        x=random.randrange(1,6)
        tab.append(x)
    print('Wyrzucone oczka: ',end='')
    
        for i in range (0,len(tab)):
        if i==len(tab):
            print(tab[i])
        else:
            print(tab[i],end=' ')
    
    print('Suma oczek:',end=' ')
    
    suma=0
    for i in range (0,len(tab)):
        suma+=tab[i]
    print(suma)
    
ilosc_rzutow=int(input('Ile razy rzucamy kostka?: '))
rzucKostka(ilosc_rzutow)